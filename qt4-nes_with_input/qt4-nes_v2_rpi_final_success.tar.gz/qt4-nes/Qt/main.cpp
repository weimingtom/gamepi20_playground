#include <QtGlobal> //Q_OS_LINUX

#include "NesEmulateWindow.h"
#include <QApplication>
#if defined(Q_OS_LINUX)
#include <QWSServer>
#endif

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

#if defined(Q_OS_LINUX)
//QApplication::setOverrideCursor(Qt::BlankCursor);
//QWSServer::setCursorVisible(false);
#endif

    NesEmulateWindow w;
    w.show();

    return a.exec();
}
