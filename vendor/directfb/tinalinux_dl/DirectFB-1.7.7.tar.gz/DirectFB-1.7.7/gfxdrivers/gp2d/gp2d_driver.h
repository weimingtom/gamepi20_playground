#ifndef __GP2D__GP2D_H__
#define __GP2D__GP2D_H__

#include <sys/ioctl.h>

#include <xf86drm.h>

#include <drm/gp2d_drm.h>

#include "gp2d_regs.h"
#include "gp2d_types.h"



#endif
