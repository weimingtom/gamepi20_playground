/********************************************************************************
** Form generated from reading UI file 'NesEmulateWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NESEMULATEWINDOW_H
#define UI_NESEMULATEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "nesscreenwidget.h"

QT_BEGIN_NAMESPACE

class Ui_NesEmulateWindow
{
public:
    QWidget *centralWidget;
    NesScreenWidget *nesScreenWidget;
    QPushButton *pushButton_open;
    QPushButton *pushButton;

    void setupUi(QMainWindow *NesEmulateWindow)
    {
        if (NesEmulateWindow->objectName().isEmpty())
            NesEmulateWindow->setObjectName(QStringLiteral("NesEmulateWindow"));
        NesEmulateWindow->resize(640, 480);
        NesEmulateWindow->setMinimumSize(QSize(640, 480));
        NesEmulateWindow->setMaximumSize(QSize(640, 480));
        NesEmulateWindow->setIconSize(QSize(0, 0));
        centralWidget = new QWidget(NesEmulateWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        nesScreenWidget = new NesScreenWidget(centralWidget);
        nesScreenWidget->setObjectName(QStringLiteral("nesScreenWidget"));
        nesScreenWidget->setGeometry(QRect(60, 0, 512, 480));
        nesScreenWidget->setMinimumSize(QSize(512, 480));
        nesScreenWidget->setMaximumSize(QSize(512, 480));
        pushButton_open = new QPushButton(centralWidget);
        pushButton_open->setObjectName(QStringLiteral("pushButton_open"));
        pushButton_open->setGeometry(QRect(0, 0, 41, 31));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(590, 0, 51, 31));
        NesEmulateWindow->setCentralWidget(centralWidget);

        retranslateUi(NesEmulateWindow);

        QMetaObject::connectSlotsByName(NesEmulateWindow);
    } // setupUi

    void retranslateUi(QMainWindow *NesEmulateWindow)
    {
        NesEmulateWindow->setWindowTitle(QApplication::translate("NesEmulateWindow", "NesEmulate Author nejidev", 0));
        pushButton_open->setText(QApplication::translate("NesEmulateWindow", "open", 0));
        pushButton->setText(QApplication::translate("NesEmulateWindow", "MENU", 0));
    } // retranslateUi

};

namespace Ui {
    class NesEmulateWindow: public Ui_NesEmulateWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NESEMULATEWINDOW_H
