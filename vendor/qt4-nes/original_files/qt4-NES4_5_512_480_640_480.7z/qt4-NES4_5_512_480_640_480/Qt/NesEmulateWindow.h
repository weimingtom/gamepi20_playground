#ifndef NESEMULATEWINDOW_H
#define NESEMULATEWINDOW_H

#include <QMainWindow>
#include <QKeyEvent>
#include <QCloseEvent>

#include "NesThread.h"
#include "NesScreenWidget.h"
namespace Ui {
class NesEmulateWindow;
}

class NesEmulateWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit NesEmulateWindow(QWidget *parent = 0);
    ~NesEmulateWindow();
    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
    void closeEvent(QCloseEvent *event);
    void on_actionOpen_triggered();
    void on_actionExit_triggered();
private slots:
    void on_pushButton_open_clicked();
    void on_pushButton_clicked();

public:
    Ui::NesEmulateWindow *ui;
    NesThread *nesThread;
    NesScreenWidget *nesScreenWidget;
};

#endif // NESEMULATEWINDOW_H
