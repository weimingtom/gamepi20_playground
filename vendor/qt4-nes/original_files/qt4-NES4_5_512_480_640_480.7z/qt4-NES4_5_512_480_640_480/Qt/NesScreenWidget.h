#ifndef NESSCREENWIDGET_H
#define NESSCREENWIDGET_H

#include <QObject>
#include <QMutex>
#include <QImage>
#include <QWidget>
#include <QBasicTimer>
class NesScreenWidget : public QWidget
{
    Q_OBJECT

protected:
    void paintEvent(QPaintEvent *event);
    void resizeEvent(QResizeEvent *event);
    void timerEvent(QTimerEvent *event);
public slots:
    void loadFrame();
    int make_zoom_tab();
    void InfoNES_LoadFrame();
private:
    QImage image;
    QImage image1;
    QMutex mutex;
    QBasicTimer timer;
    unsigned char *grayFrameBuff;
public:
    bool isGray;
public:
    NesScreenWidget(QWidget *parent);

    ~NesScreenWidget();
};

#endif // NESSCREENWIDGET_H
