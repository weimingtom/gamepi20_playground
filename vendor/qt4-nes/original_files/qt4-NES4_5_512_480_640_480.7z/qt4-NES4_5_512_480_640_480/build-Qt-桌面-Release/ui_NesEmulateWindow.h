/********************************************************************************
** Form generated from reading UI file 'NesEmulateWindow.ui'
**
** Created by: Qt User Interface Compiler version 4.8.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NESEMULATEWINDOW_H
#define UI_NESEMULATEWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QStatusBar>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NesEmulateWindow
{
public:
    QAction *actionOpen;
    QAction *actionExit;
    QAction *actionTrueColour;
    QAction *actionGray;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QWidget *nesScreenWidget;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuSeting;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *NesEmulateWindow)
    {
        if (NesEmulateWindow->objectName().isEmpty())
            NesEmulateWindow->setObjectName(QString::fromUtf8("NesEmulateWindow"));
        NesEmulateWindow->resize(256, 280);
        actionOpen = new QAction(NesEmulateWindow);
        actionOpen->setObjectName(QString::fromUtf8("actionOpen"));
        actionExit = new QAction(NesEmulateWindow);
        actionExit->setObjectName(QString::fromUtf8("actionExit"));
        actionTrueColour = new QAction(NesEmulateWindow);
        actionTrueColour->setObjectName(QString::fromUtf8("actionTrueColour"));
        actionTrueColour->setCheckable(true);
        actionTrueColour->setChecked(true);
        actionGray = new QAction(NesEmulateWindow);
        actionGray->setObjectName(QString::fromUtf8("actionGray"));
        actionGray->setCheckable(true);
        centralWidget = new QWidget(NesEmulateWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        nesScreenWidget = new QWidget(centralWidget);
        nesScreenWidget->setObjectName(QString::fromUtf8("nesScreenWidget"));

        verticalLayout->addWidget(nesScreenWidget);

        NesEmulateWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(NesEmulateWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 256, 19));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuSeting = new QMenu(menuBar);
        menuSeting->setObjectName(QString::fromUtf8("menuSeting"));
        NesEmulateWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(NesEmulateWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        NesEmulateWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuSeting->menuAction());
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionExit);
        menuSeting->addAction(actionTrueColour);
        menuSeting->addAction(actionGray);

        retranslateUi(NesEmulateWindow);

        QMetaObject::connectSlotsByName(NesEmulateWindow);
    } // setupUi

    void retranslateUi(QMainWindow *NesEmulateWindow)
    {
        NesEmulateWindow->setWindowTitle(QApplication::translate("NesEmulateWindow", "NesEmulate Author nejidev", 0, QApplication::UnicodeUTF8));
        actionOpen->setText(QApplication::translate("NesEmulateWindow", "Open", 0, QApplication::UnicodeUTF8));
        actionExit->setText(QApplication::translate("NesEmulateWindow", "Exit", 0, QApplication::UnicodeUTF8));
        actionTrueColour->setText(QApplication::translate("NesEmulateWindow", "True colour", 0, QApplication::UnicodeUTF8));
        actionGray->setText(QApplication::translate("NesEmulateWindow", "Gray", 0, QApplication::UnicodeUTF8));
        menuFile->setTitle(QApplication::translate("NesEmulateWindow", "File", 0, QApplication::UnicodeUTF8));
        menuSeting->setTitle(QApplication::translate("NesEmulateWindow", "Seting", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class NesEmulateWindow: public Ui_NesEmulateWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NESEMULATEWINDOW_H
